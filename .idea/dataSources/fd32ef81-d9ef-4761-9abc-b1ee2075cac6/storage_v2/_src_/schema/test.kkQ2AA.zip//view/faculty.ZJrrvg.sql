create view faculty as
select `test`.`instructor`.`ID`        AS `ID`,
       `test`.`instructor`.`name`      AS `name`,
       `test`.`instructor`.`dept_name` AS `dept_name`
from `test`.`instructor`;

